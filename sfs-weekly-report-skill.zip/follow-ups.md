# 持续关注事件

## F001｜越南 Mr Pips 案中的 9Pay

- 指定日期：2026-11-17
- 状态：持续关注
- 关注重点：9Pay 在案中的资金流角色；针对 9Pay 的司法或监管调查阶段；9Pay 的回应和相关商户账户处置。其他案情只有在解释或改变上述重点时才进入时间线。
- 事件背景：越南检方指控 Mr Pips 等人经营虚假的股票、外汇交易平台，诱导投资者入金；庭审涉及通过银行账户和支付中介接收资金。被告提及 9Pay 是曾使用的支付网关之一。被提及或列入后续核查不等于已被起诉或认定违法。
- 最近公开进展：检方在 2026-11-04 表示拟在第二阶段核查 9Pay 等支付中介的活动；9Pay 向 Fintech News 称已冻结并暂停与案件相关的商户账户。11 月 7 日越南法院报进一步转述检方对包括 9Pay 在内的三家支付中介的代收代付合同及关联账户证据，但未给出 9Pay 单独经手金额或认定其明知参与诈骗。11 月 9 日移动支付网复述旧庭审，所称“9Pay 尚未回应”与 11 月 6 日已披露的书面回应不一致，不能作为新调查动作。主案 2026-11-16 一审宣判，后续仍需分别核查 9Pay 的法律状态与账户处置是否有新公告。
- 后续核查问题：是否有针对 9Pay 的正式调查、起诉、处罚或牌照措施？9Pay 对涉案账户的处理是否更新？相关报道是否区分特定涉案商户与其他账户？
- 来源：[11 月 4 日庭审报道](https://vtcnews.vn/vu-mr-pips-tiep-tuc-dieu-tra-hoat-dong-5-cong-thanh-toan-va-hon-1-400-nguoi-ar1049287.html) · [11 月 6 日 9Pay 回应](https://fintechnews.sg/140658/vietnam/mr-pips-fraud-case-vietnam-payments/) · [11 月 7 日法院报道](https://congly.vn/vu-pho-duc-nam-lam-ro-mang-luoi-tai-khoan-ngan-hang-lien-quan-den-he-thong-36-san-giao-dich-546673.html) · [11 月 9 日中文报道](https://www.mpaypass.com.cn/news/202611/09095334.html) · [11 月 16 日主案判决报道](https://e.vnexpress.net/news/news/crime/vietnam-s-biggest-forex-fraud-boss-mr-pips-gets-life-in-prison-for-60m-scam-5145352.html)
